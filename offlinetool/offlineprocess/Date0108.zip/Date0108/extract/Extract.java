package com.apple.video.offlineprocess.extract;
/*
 * Extract keyframe and wav 
 * input :video path / outputpath
 * output:keyframe + wav
 * */
import java.io.*;


public class Extract {
	String ffmpegtool = null;
	File folder = null;
	
	public Extract(){
		ffmpegtool = "ffmpeg.exe";
	}
//	0108�޸ģ�������ȡkeyframe����
	public void ExtractEach(String filename,String outpath)
	{
//		��ȡ�ؼ�֡
		FramesExtraction video = new FramesExtraction(ffmpegtool);
		video.ExtractEach(filename, outpath);
			
//		��ȡ����
		WavExtraction wav = new WavExtraction(ffmpegtool);
		wav.ExtractEach(filename, outpath);
		
	}
		
	
	public static void main(String[] args)throws Exception //throws Exception
	{
		Extract fe = new Extract();
		fe.ExtractEach("d:/testvideo/0000sIheness._-o-_.sheness_512kb.mp4","D:/testvideokeyframe");
	}
}



