package com.apple.video.offlineprocess.extract;
/*
 * Date: 2013 0108
 * author: apple
 * diy wavextraction
 * */
import java.io.File;
import java.util.List;

public class WavExtraction {
	private String ffmpegtool; 
	public WavExtraction(String ffmpegtool)
	{
		this.ffmpegtool = ffmpegtool;
	}
	public void ExtractEach(String filename,String outpath)
	{
		List<String> commend=new java.util.ArrayList<String>();  
		commend.add(ffmpegtool); 
		commend.add("-i");  
	    commend.add(filename);  
	    commend.add("-ar"); 
	    commend.add("16000");
	    commend.add("-y");
	    outpath +="/wav/";
	    File file = new File(outpath);
	    if(!file.exists())
	    	file.mkdirs();
//	    ע�⣺·����д��������в���Ҫһ��
	    outpath += filename.substring(filename.lastIndexOf("\\")+1,filename.lastIndexOf("."))+".wav";
	    System.out.println(outpath);
	    commend.add(outpath);
	    try {  
	         ProcessBuilder builder = new ProcessBuilder();  
	         builder.command(commend);  
	         builder.start();  
	        } catch (Exception e) {  
	            e.printStackTrace();  
	            return;  
	        }
	}
	public static void main(String args[])
	{
		
	}

}
