package com.apple.video.offlineprocess;

import org.eclipse.swt.widgets.Display;

import com.apple.video.offlineprocess.extract.Extract;

public class Task {
	private taskUI gui;
	private boolean stopFlag;
	private boolean[] isDone;//������ʵʱ�ر�ʾ��Ƶ�������
	private Extract extract;
	
	public Task(taskUI taskGUI2){
		this.gui = taskGUI2;
		extract = new Extract();
	}
	public void stop(){
		stopFlag = true;
	}
	public void start(String[] files,String outpath,int taskCount)
	{
		String filename;
//		String currentOut;
		stopFlag = false;
		isDone = new boolean[taskCount];
		for(int i =0;i<taskCount;i++)
		{
			if(stopFlag)
				break;
			filename = files[i];
			System.out.println("++++++++++++filename"+filename);
			System.out.println("++++++++++++outpath"+outpath);
			
			//				TODO:work goes here
//			currentOut = outpath+"/"+filename.substring(filename.lastIndexOf("\\")+1,filename.lastIndexOf("."));
//			extract.ExtractEach(filename, currentOut);
			extract.ExtractEach(filename, outpath);
			isDone[i] = true;
			
			moveProgressBar(i+1);
			refreshTableViewer(files,isDone);
		}
		setTaskGUIButtonState(true);
	}
	public void start(int taskCount){
		stopFlag = false;
		for(int i =0;i<taskCount;i++)
		{
			if(stopFlag)
				break;
			try{
				Thread.sleep(100);
			}catch(InterruptedException e){
				e.printStackTrace();
			}
//			moveProgressBar(i+1);
			
		}
		setTaskGUIButtonState(true);
		
	}
	/*
	 * ���水ť״̬
	 * */
	private void setTaskGUIButtonState(final boolean bFlag){
		Display.getDefault().asyncExec(new Runnable(){
			public void run(){
				gui.setButtonState(bFlag);
				//TODO:ʵ��������ġ�ִ�а�ť��Ӧ�ý��������´��������µ���Ƶ��ʱ���ٿ���
			}
		});
	}
	/*
	 * ��������ʾ
	 * */
	private void moveProgressBar(final int progress){
		Display.getDefault().syncExec(new Runnable(){
			public void run(){
				gui.getProgressBar().setSelection(progress);
			}
		});
	}
	/*
	 *�����ı� 
	 */
	private void refreshTableViewer(final String[] files,final boolean[] isDone)//final boolean[] idDone
	{
		Display.getDefault().syncExec(new Runnable(){
			public void run(){
				Object data = PeopleFactory.getPeoples(files,isDone);
				gui.getConsoleTableViewer().setInput(data);
				}
			});
	}
//	private void insertConsoleText(final String[] files){
//		Display.getDefault().syncExec(new Runnable(){
//			public void run(){
//				
////				Object data = PeopleFactory.getPeoples(files);
////				gui.getConsoleTableViewer().setInput(data);
////				gui.getConsoleTableViewer().setContentProvider(new TableViewerContentProvider());
////				gui.getConsoleTableViewer().setLabelProvider(new TableViewerLabelProvider());
//				// ���岽����TableViewer��setInput�������������뵽����
////				if(files!=null)
////				{
////					Object data = PeopleFactory.getPeoples(files);
////					gui.getConsoleTableViewer().setInput(data);
////				}
//				
//				
//			}
//		});
//	}
}
