package com.apple.video.offlineprocess.extract;
/*
 * Date: 2013 0108
 * author: apple
 * diy frameextraction
 * */
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

public class FramesExtraction {
	String ffmpegtool = null;
	File folder = null;
	
	public FramesExtraction(String ffmpegtool){
		this.ffmpegtool = ffmpegtool;
	}
	
	
	/*
	 * ����Ƶʱ��ת��������Ϊ��λ��ʱ������
	 * */
	private int convertTime(String durationTime)
	{
		durationTime = durationTime.substring(0,durationTime.indexOf("."));
		String[] times = durationTime.split(":");
		//for(String time:times)
		//System.out.println(Integer.parseInt(time.trim()));
		return Integer.parseInt(times[2].trim())+
				Integer.parseInt(times[1].trim())*60+
				Integer.parseInt(times[0].trim())*3600;
	}
	/*
	 * �õ���Ƶ�ĳ��ȣ���Duration���ж�ȡ
	 * */
	private int getLength(String inputPath)
	{
		int length =0;
		 List<String> commend=new java.util.ArrayList<String>();  
		 commend.add(ffmpegtool);  
	     commend.add("-i");  
	     commend.add(inputPath);  
       try {  
	            ProcessBuilder builder = new ProcessBuilder();  
	            builder.command(commend);  
	            builder.redirectErrorStream(true);  
	            Process p= builder.start();  
	           //1. start  
	            BufferedReader buf = null; // ����ffmpeg����������  
	            String line = null;  
	          //read the standard output  
	            buf = new BufferedReader(new InputStreamReader(p.getInputStream()));  
	            while ((line = buf.readLine()) != null ) { 
	            	if(line.contains("Duration"))
	    			{
	            		//line ��ȡ������Ƶʱ�����ǲ����Ӵ�
	            		line = line.substring(line.indexOf(":")+1,line.indexOf(","));
	    				length = convertTime(line);
	    				return length;
	    			}
                }  
	            //�����߳����������ȴ��ⲿת���������гɹ����н����󣬲�����ִ��
	            //int ret = p.waitFor(); //1. end  
	            p.waitFor();
	        } catch (Exception e) {  
	        	e.printStackTrace();
	        } 
	        return length;
	}
	/*
	 * input���ļ�·��+����ļ��е�·��
	 *   rate:��ָ��ȡ�ڼ����ͼ����
	 *   */
	private void ExtractEach(String filepath,String outpath,int rate)
	{
	     String[] commend = new String[11];
	     commend[0] = "tools/ffmpeg";
	     commend[1] = "-i";
	     commend[2] = filepath;
	     commend[3] = "-y";
	     commend[4] = "-f";
	     commend[5] = "image2";
	     commend[6] = "-ss";
	     commend[7] = ""+rate;//"60"
	     commend[8] = "-vframes";
	     commend[9] = "1";
	     /*
	      * �Լ�дһ���ļ��У�����Щ��ȡ��ͼƬ
	      * */
	     //ע�⣺·����//д��
	     File file = new File(outpath+"/frames/"+filepath.substring(filepath.lastIndexOf("\\")+1,filepath.lastIndexOf(".")));
	     if(!file.exists())
	    	 file.mkdirs();
		 filepath = file.getAbsolutePath();
	     commend[10] = filepath+"/"+rate+".jpg";
	     try { 
	    	 
				Process pro = Runtime.getRuntime().exec(commend);
				BufferedReader br = new BufferedReader(new InputStreamReader(pro.getErrorStream()));
				String str;
				while((str = br.readLine())!=null)
				System.out.println(str);
				pro.waitFor(); 
			} catch (IOException e) { 
			e.printStackTrace();
			}catch (InterruptedException e2) { 
			e2.printStackTrace();
			return ;
			} 
	}
	public void ExtractEach(String vname,String outpath)
	{
		int vlength = 0;
		int j = 0;
		vlength = getLength(vname);
		for(int i =0;i<vlength;i++)
		{
			j=i/3;
			ExtractEach(vname,outpath,j);
		}
	}
	public static void main(String args[])
	{
		String filefolder = "d:/testvideo/0000sIheness._-o-_.sheness_512kb.mp4";
		String outpath = "D:/testvideokeyframe";
		FramesExtraction f = new FramesExtraction("tools/ffmpeg");
		f.ExtractEach(filefolder, outpath);
	}

}
